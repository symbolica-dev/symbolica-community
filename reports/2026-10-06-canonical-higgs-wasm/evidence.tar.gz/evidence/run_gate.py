"""Capture one real gate's terminal exit and wall time without logging environment."""
import datetime
import json
from pathlib import Path
import subprocess
import sys
import time

label, *command = sys.argv[1:]
assert command and label.replace('-', '').replace('_', '').isalnum()
directory = Path(__file__).resolve().parent
started = time.time()
with (directory / f'{label}.log').open('wb') as log:
    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=False)
finished = time.time()
report = {
    'label': label,
    'command': command,
    'started_utc': datetime.datetime.fromtimestamp(started, datetime.UTC).isoformat(),
    'finished_utc': datetime.datetime.fromtimestamp(finished, datetime.UTC).isoformat(),
    'elapsed_seconds': finished - started,
    'exit_code': result.returncode,
    'status': 'passed' if result.returncode == 0 else 'failed',
}
(directory / f'{label}-process.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2), flush=True)
raise SystemExit(result.returncode)
