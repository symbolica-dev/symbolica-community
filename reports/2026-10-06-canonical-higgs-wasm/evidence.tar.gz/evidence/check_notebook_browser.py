import asyncio
import json
import os
import re
from pathlib import Path
from time import perf_counter

from playwright.async_api import async_playwright


async def main():
    output = Path('/common/dev/symbolica-community/canonical-higgs-wasm/target/canonical-higgs-wasm-validation/browser')
    output.mkdir()
    assert len(os.sched_getaffinity(0)) == 1
    assert not os.environ.get('SYMBOLICA_LICENSE')
    assert not os.environ.get('SYMBOLICA_LICENSE_KEY')
    report = {'schema': 'gg-hg-visible-notebook-browser-v1', 'status': 'running',
              'cpu_affinity': sorted(os.sched_getaffinity(0)), 'console_errors': [],
              'page_errors': [], 'failed_requests': [], 'progress': []}
    started = perf_counter()
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        report['browser_version'] = browser.version
        page = await browser.new_page(viewport={'width': 1440, 'height': 1100})
        page.on('console', lambda msg: report['console_errors'].append([perf_counter() - started, msg.text[:2000]]) if msg.type == 'error' else None)
        page.on('pageerror', lambda e: report['page_errors'].append(str(e)))
        page.on('requestfailed', lambda r: report['failed_requests'].append({'url': r.url, 'failure': r.failure}))
        try:
            await page.goto('http://127.0.0.1:8880/')
            await page.get_by_role('heading', name='Transport in physical kinematics', exact=True).wait_for(timeout=180000)
            report['setup_seconds'] = perf_counter() - started
            await page.get_by_role('heading', name='Transport in physical kinematics', exact=True).scroll_into_view_if_needed()
            await page.screenshot(path=str(output / 'during-transport.png'))
            last = ''
            for _ in range(200):
                body = await page.locator('body').inner_text()
                progress = [line for line in body.splitlines() if 'Transporting masters' in line or ('Transport:' in line and 'exact cache hits' in line)]
                state = '\n'.join(progress)
                if state != last:
                    report['progress'].append([perf_counter() - started, state])
                    print(report['progress'][-1], flush=True)
                    last = state
                if 'Exact repeated cache hit: True, ODE steps: 0.' in body:
                    break
                await asyncio.sleep(5)
            else:
                raise AssertionError('Notebook did not finish its native cache-repeat assertion')
            report['total_page_seconds'] = perf_counter() - started
            await page.get_by_role('heading', name='Coherent observables', exact=True).wait_for()
            assert not await page.get_by_role('button', name='2 · Load or compute transport', exact=True).count()
            # The actual Python call is rendered, rather than only a descriptive caption.
            assert '_system.evaluate(' in body and 'options=options' in body
            assert 'amplitude.evaluate(' in body
            assert 'model = Model.standard_model()' in body
            assert 'with_form_factor_vertices(model)' in body
            assert 'get_citations()' in body
            await page.get_by_role('heading', name='Coherent observables', exact=True).scroll_into_view_if_needed()
            await page.get_by_text('electroweak_squared', exact=True).wait_for(timeout=60000)
            await asyncio.sleep(5)
            body = await page.locator('body').inner_text()
            assert 'AMFlow 2.0' in body and 'DiffExp' in body
            cells = await page.locator('td, [role="cell"]').all_text_contents()
            (output / 'table-cells.json').write_text(json.dumps(cells, indent=2) + '\n')
            scientific = [value for value in cells if re.search(r'[+-]?\d\.\d{20}e[+-]\d+', value)]
            assert len(scientific) >= 11, ('Missing scientific table values', cells)
            report['scientific_table_cells'] = len(scientific)
            assert not report['page_errors'], report['page_errors']
            assert not report['console_errors'], report['console_errors']
            assert not report['failed_requests'], report['failed_requests']
            report['status'] = 'passed'
            print('PASSED', report['total_page_seconds'], flush=True)
        except BaseException as error:
            report['status'] = 'failed'
            report['failure'] = f'{type(error).__name__}: {error}'
            raise
        finally:
            (output / 'page.txt').write_text(await page.locator('body').inner_text())
            await page.screenshot(path=str(output / 'page.png'), full_page=True)
            (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
            await browser.close()


asyncio.run(main())
