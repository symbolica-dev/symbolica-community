import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, readdir, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const wheelDirectory = resolve(process.argv[2]);
const output = resolve(process.argv[3]);
const runtime = process.env.PYODIDE_DIST_DIR;
assert(runtime, 'PYODIDE_DIST_DIR is required');
const wheels = (await readdir(wheelDirectory)).filter(n => n.endsWith('-pyemscripten_2026_0_wasm32.whl'));
assert.equal(wheels.length, 1);
const wheel = wheels[0];
const wheelBytes = await readFile(join(wheelDirectory, wheel));
const { loadPyodide } = await import(pathToFileURL(join(runtime, 'pyodide.mjs')));
const pyodide = await loadPyodide({indexURL: runtime, env: Object.fromEntries(Object.entries({
  SYMBOLICA_LICENSE_KEY: process.env.SYMBOLICA_LICENSE_KEY || '',
  SYMBOLICA_LICENSE: process.env.SYMBOLICA_LICENSE_KEY || process.env.SYMBOLICA_LICENSE || '',
}).filter(([,value]) => value))});
await pyodide.loadPackage('micropip');
pyodide.FS.writeFile(`/${wheel}`, wheelBytes);
pyodide.globals.set('wheel_uri', `emfs:/${wheel}`);
await pyodide.runPythonAsync(`
import os, micropip
await micropip.install(wheel_uri)
from symbolica import set_license_key
if os.environ.get('SYMBOLICA_LICENSE_KEY'):
    set_license_key(os.environ['SYMBOLICA_LICENSE_KEY'])
`);
const modelBytes = await readFile('examples/hep/data/gg_hg/native-model.json');
const referenceBytes = await readFile('examples/hep/data/gg_hg/amplitude-validation.json');
pyodide.globals.set('legacy_model_json', modelBytes.toString());
pyodide.globals.set('reference_json', referenceBytes.toString());
await pyodide.runPythonAsync(await readFile(new URL('./check_standard_model_amplitude.py', import.meta.url), 'utf8'));
const report = JSON.parse(pyodide.globals.get('report_json'));
report.wheel = wheel;
report.wheel_sha256 = createHash('sha256').update(wheelBytes).digest('hex');
report.legacy_model_sha256 = createHash('sha256').update(modelBytes).digest('hex');
report.amplitude_reference_sha256 = createHash('sha256').update(referenceBytes).digest('hex');
report.pyodide_version = pyodide.version;
await writeFile(output, JSON.stringify(report, null, 2) + '\n');
console.log(`Passed: ${output}`);
