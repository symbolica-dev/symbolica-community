"""Actual-Pyodide component gate; archived inputs are not new transport evidence."""
import json
from time import perf_counter
from symbolica import ComplexFloat, E, Expression, Float
from symbolica.community.hep.integration import HiggsJetAmplitude, InvalidInputError
from symbolica.community.hepkit import Model, Process

started = perf_counter()
sm = Model.standard_model()
original_json = sm.to_json()
model = HiggsJetAmplitude.with_form_factor_vertices(sm)
assert type(model) is Model
assert sm.to_json() == original_json
assert isinstance(model.parameter('GGGHEWWW_ForFac1_RE').symbol, Expression)
assert isinstance(model.coupling('GGGH_HEFT_C1').expression, Expression)
vertices = ['GGGHEWWW', 'GGGHEWZZ', 'GGGHHEFT']
assert isinstance(model.process(['g', 'g'], ['g', 'H'], vertex_allow=vertices), Process)
for vertex in vertices:
    assert model.vertex_rule(vertex).particles == ['g', 'g', 'g', 'H']
model_json = model.to_json()
try:
    HiggsJetAmplitude.with_form_factor_vertices(model)
except InvalidInputError as error:
    assert 'already exists' in str(error)
else:
    raise AssertionError('Conflicting form-factor declarations were overwritten')
assert model.to_json() == model_json and sm.to_json() == original_json
assert Model.from_json(model_json).to_json() == model_json
legacy_model = Model.from_json(legacy_model_json)
construction_started = perf_counter()
standard_kernel = HiggsJetAmplitude(model)
standard_construction_seconds = perf_counter() - construction_started
construction_started = perf_counter()
legacy_kernel = HiggsJetAmplitude(legacy_model)
legacy_construction_seconds = perf_counter() - construction_started
assert len(standard_kernel.expressions) == len(legacy_kernel.expressions) == 3
kernel_equal = [(a - b).expand() == E('0') for a, b in zip(standard_kernel.expressions, legacy_kernel.expressions, strict=True)]
assert all(kernel_equal), kernel_equal
assert len(standard_kernel.diagrams) == len(legacy_kernel.diagrams) == 3
reference = json.loads(reference_json)
s, t, mh2 = [E(x) for x in reference['physical_s_t_MH_squared']]
mw2, mz2 = E('5399/13074'), E('7775/14631')
parameter_values = {'aEWM1': E('128'), 'aS': E('118/1000'), 'MZ': mz2.sqrt(),
    'Gf': E('𝜋') * E('1/128') * mz2 / (E('2').sqrt() * mw2 * (mz2-mw2))}
factors, errors = {}, {}
for block in reference['form_factors']:
    rows = sorted(block['values'], key=lambda x: x['index'])
    assert [x['index'] for x in rows] == [1,2,3,4]
    factors[block['mass']] = [ComplexFloat(x['real'], x['imaginary'], decimal_digits=110) for x in rows]
    errors[block['mass']] = [Float(x['absolute_error'], decimal_digits=110) for x in rows]
provenance = 'archived coherent transport; actual-Pyodide native Standard Model amplitude component check only'
results = []
for kernel, selected_model in [(standard_kernel, model), (legacy_kernel, legacy_model)]:
    results.append(kernel.evaluate(s, t, mh2, factors['W'], factors['Z'], errors['W'], errors['Z'],
        parameters={selected_model.parameter(k).symbol:v for k,v in parameter_values.items()},
        digits=20, guard_digits=40, provenance=provenance))
standard, legacy = results
assert standard.working_bits == legacy.working_bits
assert standard.verified_relative_digits == legacy.verified_relative_digits
assert standard.provenance == legacy.provenance == provenance
for property_name in ('values', 'absolute_errors', 'arithmetic_changes'):
    a, b = getattr(standard, property_name), getattr(legacy, property_name)
    assert a.keys() == b.keys()
    for name in a:
        assert a[name].as_integer_ratio() == b[name].as_integer_ratio(), (property_name, name)
        assert a[name].precision == b[name].precision, (property_name, name)
observables = {}
for name, value in standard.values.items():
    expected = Float(reference['expected_observables'][name], decimal_digits=110)
    allowance = reference['reference_accuracy'][name]
    reference_error = Float(allowance['input_absolute_error'], decimal_digits=110) + Float(allowance['rounding_absolute_error'], decimal_digits=110)
    difference = abs(value - expected)
    assert difference <= abs(expected) * Float('1e-30', decimal_digits=110), name
    assert difference <= standard.absolute_errors[name] + reference_error, name
    observables[name] = {'value':str(value), 'absolute_error':str(standard.absolute_errors[name]),
        'working_precision':value.precision, 'error_precision':standard.absolute_errors[name].precision,
        'verified_relative_digits':standard.verified_relative_digits[name], 'absolute_difference':str(difference),
        'reference_error':str(reference_error), 'arithmetic_change':str(standard.arithmetic_changes[name])}
assert standard.verified_relative_digits['electroweak_squared'] == 19
assert standard.verified_relative_digits['interference'] >= 20
report_json = json.dumps({'status':'passed','scope':'Actual Pyodide shared owner/model extension and three exact scalar kernels; archived form-factor amplitude component comparison, not fresh native transport or a new boundary-accuracy certificate.',
    'exact_kernel_equal':kernel_equal,'shared_native_model':True,'typed_collision':True,
    'values_errors_arithmetic_changes_and_precision_exactly_match_legacy':True,
    'working_bits':standard.working_bits,'observables':observables,
    'standard_construction_seconds':standard_construction_seconds,'legacy_construction_seconds':legacy_construction_seconds,
    'total_seconds':perf_counter()-started},indent=2)
print(report_json)
