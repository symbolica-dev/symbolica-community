from pathlib import Path
import datetime, hashlib, io, json, os, re, tarfile, gzip, zipfile
root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
sha=lambda b: hashlib.sha256(b).hexdigest()
freeze=json.loads((out/'source-freeze.json').read_text())
for name,digest in freeze['source_files'].items():
    assert sha((root/name).read_bytes())==digest, f'Source changed during build: {name}'
processes={}
for name in ('build','dependency-graphs','wheel-layout','community-pyodide','standard-model-amplitude','notebook-export','notebook-browser'):
    data=json.loads((out/f'{name}-process.json').read_text()); assert data['exit_code']==0,data
    processes[name]=data
component=json.loads((out/'standard-model-amplitude.json').read_text())
browser=json.loads((out/'browser/report.json').read_text())
assert component['status']==browser['status']=='passed'
wheels=list((root/'dist/canonical-higgs-wasm').glob('*.whl')); assert len(wheels)==1
wheel=wheels[0]; wheel_hash=sha(wheel.read_bytes())
marker=json.loads((wheel.parent/'loop-transport-validation.json').read_text())
assert marker['wheel_sha256']==wheel_hash and marker['higgs_standard_model']
with zipfile.ZipFile(wheel) as z:
    core=z.read('symbolica/core.abi3.so')
report={'schema':'canonical-higgs-wasm-publication-validation-v1','status':'passed',
        'created_utc':datetime.datetime.now(datetime.UTC).isoformat(),
        'tools':json.loads((out/'tool-versions.json').read_text()),
        'source_parent_commit':freeze['parent_commit'],'source_unchanged_files':len(freeze['source_files']),
        'source_notebook_sha256':freeze['source_files']['examples/hep/gg_hg.py'],
        'locked_owners':json.loads((out/'locked-owners.json').read_text()),
        'wheel':{'name':wheel.name,'sha256':wheel_hash,'bytes':wheel.stat().st_size,'core_sha256':sha(core)},
        'processes':processes,'pyodide_marker':marker,'standard_model_amplitude_component':component,
        'fresh_browser_notebook':browser,
        'development_failures':[{'gate':'notebook export','cause':'Existing uv executable was absent from this shell PATH; added its bin directory and repeated export into a fresh bundle.','source_change':False}],
        'scope':['Complete canonical Community wheel; no extension overlays.',
                 'Actual Pyodide supplied transport, binary restart, nearby cache reuse, cancellation, shared HEPKit/Symbolica objects and new shared graph display types.',
                 'Exact Standard Model versus legacy scalar-kernel comparison and archived-input component amplitude agreement; this component retains its recorded reference precision.',
                 'Fresh one-core Chrome notebook with supplied boundaries, physical transport, coherent amplitude, repeat cache hit, citations and scientific table cells.'],
        'limits':['Supplied 40-digit boundaries; this gate does not certify generation from empty boundary caches.',
                  'Browser runtime is measured during concurrent build/test activity on other CPU cores, not a controlled performance comparison.',
                  'Numerical transport is single-core; compilation uses parallel jobs.']}
selected=['notebook-export-missing-uv.log','notebook-export-missing-uv-process.json','tool-versions.json','source-freeze.json','locked-owners.json','source-files.txt','run_gate.py','check_standard_model_amplitude.py','check_standard_model_amplitude.mjs','check_notebook_browser.py','finalize_report.py','standard-model-amplitude.json']
for name in processes: selected.extend([f'{name}-process.json',f'{name}.log'])
selected.extend(['browser/report.json','browser/page.txt','browser/table-cells.json','browser/page.png','browser/during-transport.png'])
files={f'evidence/{name}':(out/name).read_bytes() for name in selected}
for name in ['Cargo.toml','Cargo.lock','pyproject.toml','src/hepkit.rs','src/lib.rs','src/citations.rs','tests/integration_contract.py','tests/check_offline_rendering.py','.github/scripts/test_pyodide.mjs','.github/scripts/check_wasm_loop_transport.py','.github/scripts/check_integration_package.py','scripts/build_wasm_performance.sh','scripts/capture_wasm_opt.py','scripts/export_gg_hg_wasm.py','scripts/serve_wasm_bundle.py','examples/hep/gg_hg.py','examples/hep/gg_hg_boundaries.py']:
    if (root/name).is_file(): files[f'source/{name}']=(root/name).read_bytes()
files['evidence/loop-transport-validation.json']=(wheel.parent/'loop-transport-validation.json').read_bytes()
files['evidence/gg-hg-assets.json']=(root/'target/canonical-higgs-wasm-notebook/gg-hg-assets.json').read_bytes()
for name,data in files.items():
    if name.endswith('.png'): continue
    for key in ('SYMBOLICA_LICENSE','SYMBOLICA_LICENSE_KEY','GH_TOKEN','GITHUB_TOKEN'):
        secret=os.environ.get(key,'')
        assert len(secret)<8 or secret.encode() not in data, f'Secret value in {name}'
    assert not re.search(rb'(?:gh[pousr]_[A-Za-z0-9]{25,}|S-\d+-\d{4}\.\d{2}\.\d{2}-[A-Z0-9]{30,})',data),f'Secret pattern in {name}'
manifest={name:sha(data) for name,data in files.items()}
files['MANIFEST.json']=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()
archive=io.BytesIO()
with gzip.GzipFile(filename='',mode='wb',fileobj=archive,mtime=0) as gz:
    with tarfile.open(fileobj=gz,mode='w') as tar:
        for name,data in sorted(files.items()):
            info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
            tar.addfile(info,io.BytesIO(data))
payload=archive.getvalue()
with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tar:
    for name,digest in manifest.items(): assert sha(tar.extractfile(name).read())==digest
report['archive']={'sha256':sha(payload),'bytes':len(payload),'members':len(files)}
destination=root/'reports/2026-10-06-canonical-higgs-wasm'
destination.mkdir(parents=True,exist_ok=False)
(destination/'evidence.tar.gz').write_bytes(payload)
(destination/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'report':str(destination),'archive':report['archive'],'browser_seconds':browser['total_page_seconds']},indent=2))
