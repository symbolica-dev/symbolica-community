import hashlib
import importlib
import json
from pathlib import Path
from zipfile import ZipFile

root = Path(__file__).resolve().parent
wheels = list((root / "dist").glob("*.whl"))
assert len(wheels) == 1, wheels
wheel = wheels[0]
core = Path(importlib.import_module("symbolica.core").__file__).resolve()
assert core.is_relative_to(root / "venv"), core
digest = lambda data: hashlib.sha256(data).hexdigest()
with ZipFile(wheel) as archive:
    entries = [name for name in archive.namelist()
               if name.startswith("symbolica/core.") and name.endswith(".so")]
    assert len(entries) == 1, entries
    assert digest(archive.read(entries[0])) == digest(core.read_bytes())
record = {
    "runtime_kind": "complete native community wheel installed in an isolated environment",
    "source": str(core),
    "sha256": digest(core.read_bytes()),
    "wheel": str(wheel),
    "wheel_sha256": digest(wheel.read_bytes()),
    "host_worktree": "/common/dev/symbolica-community/notebook-supplied-boundaries",
    "rustflow_revision": "9599e35867119178ba3c02d7c55b998efab641f4",
    "symbolica_revision": "58652fabc2f736302a570deaaf8d517679f7fe6e",
    "hepkit_revision": "41253945836953a99861612da786563ae3f0b3ca",
    "host_features": "python_stubgen,pyo3/extension-module",
    "no_default_features": True,
}
(root / "native-extension.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
