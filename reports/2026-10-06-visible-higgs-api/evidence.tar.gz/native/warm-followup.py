import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys
import time

ROOT = Path('/common/dev/amflow/target/gg-hg-visible-notebook-native')
original = json.loads((ROOT / 'report-initial-metadata-assertion.json').read_text())
notebook = ROOT / 'executed-gg_hg.py'
source = Path(original['notebook'])
DATA = source.parent / 'data/gg_hg'
assert hashlib.sha256(notebook.read_bytes()).hexdigest() == original['source_before'][str(source)]
for name in ['gg_hg_boundaries.py', 'data']:
    link = ROOT / name
    if not link.exists():
        link.symlink_to(source.parent / name, target_is_directory=name == 'data')
sys.path.insert(0, str(source.parent))
from symbolica import ComplexFloat, Float
from gg_hg_acceptance import check_transport_reference_coverage, compare_form_factors
from gg_hg_support import boundary_evidence

# Reuse only the pure validation/serialization functions, never the failed runner.
tree = ast.parse((ROOT / 'run-initial-metadata-assertion.py').read_text())
helpers = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in ('validate', 'exact_float', 'exact_result')]
exec(compile(ast.Module(body=helpers, type_ignores=[]), '<retained-validation-functions>', 'exec'))
os.chdir(original['cwd'])
assert os.sched_getaffinity(0) == {45}
app = runpy.run_path(str(notebook), run_name='frozen_visible_notebook_warm')['app']
started = time.perf_counter()
outputs, definitions = app.run()
elapsed = time.perf_counter() - started
checked = validate(definitions)
checked['app_run_seconds'] = elapsed
checked['rendered_output_count'] = len(outputs)
assert checked['cache_hits'] == 16 and checked['steps'] == checked['inserted_points'] == 0
cold = json.loads((ROOT / 'cold-transport-exact.json').read_text())
warm = {label: exact_result(result) for label, result in definitions['results'].items()}
for label in cold:
    for key, value in cold[label].items():
        if key == 'input_verified_digits':
            assert value == 40 and warm[label][key] == cold[label]['verified_digits'] == 28
        else:
            assert value == warm[label][key], (label, key)
assert hashlib.sha256(notebook.read_bytes()).hexdigest() == original['source_before'][str(source)]
for path, digest in original['source_before'].items():
    if path != str(source):
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, path
assert hashlib.sha256(Path(original['native_extension']['path']).read_bytes()).hexdigest() == original['native_extension']['sha256']
checked.update({'status': 'passed', 'cpu_affinity': [45],
                'notebook_snapshot': str(notebook), 'notebook_sha256': original['source_before'][str(source)],
                'scope': 'Actual app.run() with no overrides on an exact byte copy of the original executed notebook, using its isolated bank. Parent presentation source may subsequently change.',
                'coefficients_errors_precisions_identities_roots_equal_cold': True,
                'warm_input_cap_equals_retained_destination_digits': True,
                'snapshot_helpers_assets_extension_unchanged': True,
                'finish_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
(ROOT / 'warm-followup.json').write_text(json.dumps(checked, indent=2) + '\n')
print(json.dumps({k: checked[k] for k in ['status','app_run_seconds','transport_seconds','configurations','coefficients','cache_hits','steps','inserted_points']}), flush=True)
