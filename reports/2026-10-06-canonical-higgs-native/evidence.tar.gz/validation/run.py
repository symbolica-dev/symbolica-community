import datetime
import hashlib
import importlib
import json
import os
from pathlib import Path
import runpy
import sys
import tempfile
import time
import traceback

ROOT = Path('/common/dev/amflow/target/gg-hg-canonical-native')
NOTEBOOK = Path('/common/dev/symbolica-community/higgs-main-publication/examples/hep/gg_hg.py')
DATA = NOTEBOOK.parent / 'data/gg_hg'

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def write(name, record):
    (ROOT / name).write_text(json.dumps(record, indent=2) + '\n')

inputs = [NOTEBOOK, NOTEBOOK.with_name('gg_hg_boundaries.py'),
          NOTEBOOK.with_name('gg_hg_acceptance.py'), NOTEBOOK.with_name('gg_hg_support.py')]
inputs += sorted(DATA.glob('*.*'))
before = {str(path): digest(path) for path in inputs}
sys.path.insert(0, str(NOTEBOOK.parent))
from symbolica import ComplexFloat, Float, get_citations
from gg_hg_acceptance import check_transport_reference_coverage, compare_form_factors
from gg_hg_support import boundary_evidence

core = importlib.import_module('symbolica.core')
extension = Path(core.__file__).resolve()
provenance = json.loads((ROOT / 'native-extension.json').read_text())
assert digest(extension) == provenance['sha256']
assert len(provenance['rustflow_revision']) == 40
working = Path(tempfile.mkdtemp(prefix='run-', dir=ROOT))
os.chdir(working)
assert os.sched_getaffinity(0) == {45}
report = {'status': 'running', 'start_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'python': sys.executable, 'python_version': sys.version, 'cpu_affinity': [45],
          'cwd': str(working), 'notebook': str(NOTEBOOK), 'source_before': before,
          'native_extension': {'path': str(extension), 'sha256': digest(extension), **provenance},
          'scope': 'Actual unmodified notebook app.run() with no definition overrides. Cold destination transport uses supplied 40-digit starting boundaries. Native shared host using the recorded RustFlow revision and the Standard Model vertex extension. No new boundary generation or WASM timing claim.',
          'runs': {}}
write('report.json', report)
print('START', json.dumps({'notebook_sha256': before[str(NOTEBOOK)], 'cwd': str(working), 'extension_sha256': digest(extension)}), flush=True)

def exact_float(value):
    a, b = value.as_integer_ratio()
    return [str(a), str(b), value.precision]

def exact_result(result):
    return {'coefficients': [[[exact_float(z.real), exact_float(z.imag)] for z in row]
                             for row in result.coefficients],
            'comparison_errors': [[exact_float(x) for x in row] for row in result.comparison_errors],
            'verified_digits': result.verified_digits, 'input_verified_digits': result.input_verified_digits,
            'working_bits': result.working_bits, 'identity': result.identity,
            'root_sheets': {str(k): v for k, v in result.root_sheets.items()}}

def validate(defs):
    citation_ids = {entry.id for entry in get_citations()}
    assert {'arXiv:2607.08477', 'arXiv:2006.05510', 'arXiv:2201.11669', 'arXiv:2112.07578'} <= citation_ids
    reference = json.loads((DATA / 'coherent-reference.json').read_text())
    count = check_transport_reference_coverage(defs['results'], reference,
             [c.label for _, c in defs['configurations']])
    one, tolerance = Float('1', decimal_digits=100), Float('1e-20', decimal_digits=100)
    largest = Float('0', decimal_digits=100)
    for case in reference['cases']:
        result = defs['results'][case['label']]
        assert result.verified_digits >= 20 and result.leading_power == 0
        for row, expected_row in zip(result.coefficients, case['reference_values'], strict=True):
            for value, expected in zip(row, expected_row, strict=True):
                target = ComplexFloat(expected['real'], expected['imaginary'], decimal_digits=100)
                difference = abs(value - target) / max(one, abs(target))
                assert difference <= tolerance, (case['label'], str(difference))
                largest = max(largest, difference)
        for row in result.comparison_errors:
            assert all(e.is_finite() and e >= 0 for e in row)
    reference = json.loads((DATA / 'amplitude-validation.json').read_text())
    factors = compare_form_factors(defs['form_factors'], reference)
    observables = defs['observables']
    checks = {}
    assert len(observables.values) == 3
    for name, value in observables.values.items():
        expected = Float(reference['expected_observables'][name], decimal_digits=100)
        meta = reference['reference_accuracy'][name]
        ref_error = Float(meta['input_absolute_error'], decimal_digits=100) + Float(meta['rounding_absolute_error'], decimal_digits=100)
        error = observables.absolute_errors[name]
        difference = abs(value - expected)
        assert error.is_finite() and error >= 0
        assert observables.verified_relative_digits[name] >= 20
        assert difference <= error + ref_error, name
        checks[name] = {'value': str(value), 'native_absolute_error': str(error),
                        'verified_relative_digits': observables.verified_relative_digits[name],
                        'reference_absolute_error': str(ref_error), 'absolute_difference': str(difference)}
    repeated = defs['repeated']
    first_label = defs['configurations'][0][1].label
    assert repeated.cache_hit and repeated.steps == 0 and repeated.inserted_points == 0
    assert repeated.coefficients == defs['results'][first_label].coefficients
    assert repeated.comparison_errors == defs['results'][first_label].comparison_errors
    return {'configurations': len(defs['results']), 'coefficients': count,
            'maximum_scaled_reference_difference': str(largest),
            'form_factor_comparison': factors, 'observable_comparison': checks,
            'literature_citations': sorted(citation_ids), 'binary_repeated_hit': True, 'binary_repeat_errors_equal': True,
            'transport_seconds': defs['transport_seconds'],
            'cache_entries': len(defs['cache']),
            'cache_hits': sum(r.cache_hit for r in defs['results'].values()),
            'steps': sum(r.steps for r in defs['results'].values()),
            'inserted_points': sum(r.inserted_points for r in defs['results'].values())}

try:
    app = runpy.run_path(str(NOTEBOOK), run_name='visible_notebook_acceptance')['app']
    cold_exact = None
    cold_bank = None
    for mode in ('cold', 'warm'):
        assert digest(NOTEBOOK) == before[str(NOTEBOOK)]
        started = time.perf_counter()
        outputs, definitions = app.run()
        elapsed = time.perf_counter() - started
        checked = validate(definitions)
        checked['app_run_seconds'] = elapsed
        checked['rendered_output_count'] = len(outputs)
        exact = {label: exact_result(result) for label, result in definitions['results'].items()}
        write(f'{mode}-transport-exact.json', exact)
        bank = boundary_evidence(definitions['cache'])
        if mode == 'cold':
            assert checked['cache_hits'] == 0 and checked['steps'] > 0
            cold_exact, cold_bank = exact, bank
        else:
            assert checked['cache_hits'] == 16 and checked['steps'] == checked['inserted_points'] == 0
            for label, fields in cold_exact.items():
                for key, value in fields.items():
                    if key == 'input_verified_digits':
                        assert exact[label][key] == fields['verified_digits']
                        assert exact[label][key] <= value
                    else:
                        assert exact[label][key] == value, (label, key)
            checked['warm_input_cap_equals_retained_destination_digits'] = True
            assert bank == cold_bank
            checked['cold_warm_exact_values_errors_identity_equal'] = True
            checked['cold_warm_native_bank_evidence_equal'] = True
        report['runs'][mode] = checked
        write('report.json', report)
        print(mode.upper(), json.dumps({k:checked[k] for k in ['app_run_seconds','transport_seconds','configurations','coefficients','cache_hits','steps','inserted_points']}), flush=True)
    report['source_after'] = {str(path): digest(path) for path in inputs}
    assert report['source_after'] == before
    assert digest(extension) == provenance['sha256']
    report['source_and_extension_unchanged'] = True
    report['status'] = 'passed'
except BaseException as error:
    report['status'] = 'failed'
    report['error'] = repr(error)
    report['traceback'] = traceback.format_exc()
    write('report.json', report)
    raise
finally:
    report['finish_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    write('report.json', report)
print('PASSED', flush=True)
